﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App1
{
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        bool editTrue = false;

        public MainPage()
        {
            InitializeComponent();
        }
        private void btn_Clicked(object sender, EventArgs e)
        {
            if(editTrue)
            {
                editTrue = true;
                btn.Text = "Изпълни";
                nauthor.Text = "";
                sht.Text = "";
                prl.Text = "";
                chisl.Text = "";
                nrch.Text = "";
                glg.Text = "";
                lblResult.Text = ":)";
            }
            else
            {
                editTrue = false;
                String sAName = nauthor.Text;
                String sSashtestvitelno = sht.Text;
                String sPrilagatelno = prl.Text;
                String sGlagol = glg.Text;
                String sNarechie = nrch.Text;
                String sChislitelno = chisl.Text;

                String textAll = "Здравей, " + sAName + "! \r\n" +
                    "Знай че те гледам ей" + sPrilagatelno + " " + sSashtestvitelno +
                    " и че не си изми ръцете. \r\n" +
                    "После " + sGlagol + " " + sNarechie + " за да дойде. \r\n" +
                    "Но отново закъсня да ядеш" + sChislitelno + " минути. /r/n" +
                    "И браво изяде целия дюнер без да ти стане тешко.";



                lblResult.Text = textAll;
                btn.Text = "Изчисти";
                nauthor.Text = "";
                sht.Text = "";
                prl.Text = "";
                chisl.Text = "";
                nrch.Text = "";
                glg.Text = "";
                 
            }
        }
    }
}
